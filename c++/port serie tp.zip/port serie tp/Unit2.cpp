//---------------------------------------------------------------------------

#pragma hdrstop

#include "Unit2.h"
#include <vcl.h>

#include <windows.h>
bool com::ouverture(wchar_t* port)
{
	bool rep;
	hcomm=CreateFile(port,GENERIC_WRITE|GENERIC_READ,0,NULL,NULL,NULL,NULL);
	if (hcomm==INVALID_HANDLE_VALUE)
	{
		rep =false;
	}
	else
	{
		GetCommState(hcomm,&serie);
		serie.BaudRate = 9600;
		serie.ByteSize =8;
		serie.Parity = NOPARITY;
		serie.StopBits = ONESTOPBIT;
		SetCommState(hcomm,&serie);
		rep=true;
	}


	return rep;

}
void com::fermeture()
{
  CloseHandle(hcomm);
}
char * com::ecriture(char *chaine)
{
  unsigned long pt=0;
	WriteFile(hcomm,&chaine, strlen(chaine),&pt, NULL);
	PurgeComm(hcomm,PURGE_TXCLEAR);
	return chaine;

}
char* com::lecture(char *chaine)
{
  int taille=15;

	unsigned long pt;
	pt=0;
	chaine=new char[taille+1];
	chaine[0]='\0';

    over.Internal=0;
	over.InternalHigh=0;
	over.Offset=0;
	over.OffsetHigh=0;
	over.Pointer=NULL;
	over.hEvent=NULL;
	ReadFile(hcomm,chaine, taille,&pt, &over);
	PurgeComm(hcomm,PURGE_RXCLEAR);
	return chaine;

}
//---------------------------------------------------------------------------
#pragma package(smart_init)

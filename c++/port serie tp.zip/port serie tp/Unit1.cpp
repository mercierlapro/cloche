//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "Unit2.h"
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
	Form1->Label1->Visible=false;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
	Form1->Label1->Visible=true;
	bool rep=Form1->RS232->ouverture(L"com1");
	if(rep==true)
	{
		Form1->Label1->Caption="Le port est ouvert";
	}
	else
	{
	   Form1->Label1->Caption="L'ouverture du port � echou�";
	}



}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button4Click(TObject *Sender)
{
	Form1->Close();
}
//---------------------------------------------------------------------------

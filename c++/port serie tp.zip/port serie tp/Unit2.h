//---------------------------------------------------------------------------

#ifndef Unit2H
#define Unit2H
#include <windows.h>
class com
{
	private:
	HANDLE hcomm;
	DCB serie;
OVERLAPPED over;


	public:

	bool ouverture(wchar_t *port);
	void fermeture();
	char* ecriture(char *chaine);
	char* lecture(char *chaine);
};
//---------------------------------------------------------------------------
#endif
